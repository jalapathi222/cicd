# Cloud Scheduler & Dataflow Demo

The folder contains an example how to set up a cloud scheduler to trigger a Dataflow batch job.
