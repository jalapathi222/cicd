## BQ
The schema ordering doesn't matter in the json file. However the schema file is append only. Removing an existing field will break the terraform process.  
